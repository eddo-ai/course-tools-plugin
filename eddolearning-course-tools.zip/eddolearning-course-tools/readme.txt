=== Eddo Learning Course Tools ===
Contributors: eddolearning
Tags: education, chat, courses
Requires at least: 6.0
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Course tools and blocks for Eddo Learning platform integration.

== Description ==
This plugin provides blocks for integrating Eddo Learning platform features into WordPress sites.

== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/eddo-learning-course-tools` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress

== Changelog ==
= 1.0.0 =
* Initial release
